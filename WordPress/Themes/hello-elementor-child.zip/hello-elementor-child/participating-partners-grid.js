jQuery( document ).ready(function($) {
    $( ".participating-partners-item" ).on( "click", function() {
        $('#geschaefte-modal-wrapper').css({'display': 'block'});

        $('#participating-partners-loading-animation').css({'display': 'block'});
        $('#geschaefte-modal-container #geschaefte-modal-content-container').css({'display': 'none'});

        let id = $(this).data('tmid');
        let ajaxReq = $.ajax( { url : 'https://backend.mycity.cards/api/v4/partners/' + id,
            contentType : 'application/json',
            dataType : 'json',
            headers: { "Accepts": "application/json; charset=utf-8", "X-API-KEY": window.request_data.x_api_key }
        });
        ajaxReq.success( function ( data, status, jqXhr ) {
            $('#geschaefte-modal-logo').attr('src', data.logoUrl);
            $('#geschaefte-modal-companyname').html(data.companyName);
            $('#geschaefte-modal-partner-id').html(data.partnerId ? 'Partner-Nr.: ' + data.partnerId : '');

            $('#geschaefte-modal-categories').empty();
            if (data.categories && data.categories.length > 0) {
                data.categories.forEach(function (category) {
                    $('#geschaefte-modal-categories').append('<span class="geschaefte-modal-category-badge">' + category + '</span> ');
                });
            }

            $('#geschaefte-modal-boni').empty();
            if (data.anyBonusActive && data.boni && data.boni.length > 0) {
                data.boni.forEach(function (bonus) {
                    let bonusHtml = '<div class="geschaefte-modal-bonus"><strong>' + (bonus.title || '') + '</strong>';
                    if (bonus.description) {
                        bonusHtml += '<div>' + bonus.description + '</div>';
                    }
                    if (bonus.activeOnTimeText) {
                        bonusHtml += '<div>' + bonus.activeOnTimeText + '</div>';
                    }
                    bonusHtml += '</div>';
                    $('#geschaefte-modal-boni').append(bonusHtml);
                });
            }

            $('#geschaefte-modal-infotext').html(data.infoText ? data.infoText : '');

            $('#geschaefte-modal-address').html(data.street + ', ' + data.zip + ' ' + data.city + ' ' + data.country);
            if (data.latitude && data.longitude) {
                $('#geschaefte-modal-map-link').attr('href', 'https://www.google.com/maps/search/?api=1&query=' + data.latitude + ',' + data.longitude).show();
            } else {
                $('#geschaefte-modal-map-link').hide();
            }

            $('#geschaefte-modal-phone').html(data.phone);
            $('#geschaefte-modal-email').html('<a style="font-weight: normal; color: " href="mailto:' + data.email +  '">' + data.email + '</a>');
            $('#geschaefte-modal-website').attr('href', data.website);

            if (data.instagramUrl) {
                $('#geschaefte-modal-instagram').attr('href', data.instagramUrl).show();
            } else {
                $('#geschaefte-modal-instagram').hide();
            }
            if (data.facebookUrl) {
                $('#geschaefte-modal-facebook').attr('href', data.facebookUrl).show();
            } else {
                $('#geschaefte-modal-facebook').hide();
            }

            $('#geschaefte-modal-can-add-voucher').toggle(!!data.canAddVoucher);
            $('#geschaefte-modal-can-redeem-voucher').toggle(!!data.canRedeemVoucher);

            if (data.calendarBookingUrl) {
                $('#geschaefte-modal-calendar-booking').attr('href', data.calendarBookingUrl).show();
            } else {
                $('#geschaefte-modal-calendar-booking').hide();
            }

            $('#geschaefte-modal-featured-images').empty();
            if (data.featuredImageUrls && data.featuredImageUrls.length > 0) {
                data.featuredImageUrls.forEach(function (url) {
                    $('#geschaefte-modal-featured-images').append('<img src="' + url + '" class="geschaefte-modal-featured-image">');
                });
            }

            $('#geschaefte-modal-open-hours-additional-info').html(data.companyOpenHoursAdditionalInfo);
            $('#geschaefte-modal-open-hours-arrangement').toggle(!!data.companyOpenHoursOnlyByArrangement);

            if(data.closedMonday == true) {
                $( '#mon .geschaefte-modal-open-hours-times' ).append('geschlossen');
            } else {
                data.openingHours.mon.forEach((element, index) => {
                    if(index > 0) {
                        $( '#mon .geschaefte-modal-open-hours-times' ).append(', ');
                    }
                  $( '#mon .geschaefte-modal-open-hours-times' ).append(element.start + ' - ' + element.end);
                });
            }

            if(data.closedTuesday == true) {
                $( '#tue .geschaefte-modal-open-hours-times' ).append('geschlossen');
            } else {
                data.openingHours.tue.forEach((element, index) => {
                    if(index > 0) {
                        $( '#tue .geschaefte-modal-open-hours-times' ).append(', ');
                    }
                  $( '#tue .geschaefte-modal-open-hours-times' ).append(element.start + ' - ' + element.end);
                });
            }

            if(data.closedWednesday == true) {
                $( '#wed .geschaefte-modal-open-hours-times' ).append('geschlossen');
            } else {
                data.openingHours.wed.forEach((element, index) => {
                    if(index > 0) {
                        $( '#wed .geschaefte-modal-open-hours-times' ).append(', ');
                    }
                  $( '#wed .geschaefte-modal-open-hours-times' ).append(element.start + ' - ' + element.end);
                });
            }

            if(data.closedThursday == true) {
                $( '#thu .geschaefte-modal-open-hours-times' ).append('geschlossen');
            } else {
                data.openingHours.thu.forEach((element, index) => {
                    if(index > 0) {
                        $( '#thu .geschaefte-modal-open-hours-times' ).append(', ');
                    }
                  $( '#thu .geschaefte-modal-open-hours-times' ).append(element.start + ' - ' + element.end);
                });
            }

            if(data.closedFriday == true) {
                $( '#fri .geschaefte-modal-open-hours-times' ).append('geschlossen');
            } else {
                data.openingHours.fri.forEach((element, index) => {
                    if(index > 0) {
                        $( '#fri .geschaefte-modal-open-hours-times' ).append(', ');
                    }
                  $( '#fri .geschaefte-modal-open-hours-times' ).append(element.start + ' - ' + element.end);
                });
            }

            if(data.closedSaturday == true) {
                $( '#sat .geschaefte-modal-open-hours-times' ).append('geschlossen');
            } else {
                data.openingHours.sat.forEach((element, index) => {
                    if(index > 0) {
                        $( '#sat .geschaefte-modal-open-hours-times' ).append(', ');
                    }
                  $( '#sat .geschaefte-modal-open-hours-times' ).append(element.start + ' - ' + element.end);
                });
            }

            if(data.closedSunday == true) {
                $( '#sun .geschaefte-modal-open-hours-times' ).append('geschlossen');
            } else {
                data.openingHours.sun.forEach((element, index) => {
                    if(index > 0) {
                        $( '#sun .geschaefte-modal-open-hours-times' ).append(', ');
                    }
                  $( '#sun .geschaefte-modal-open-hours-times' ).append(element.start + ' - ' + element.end);
                });
            }

            $('#participating-partners-loading-animation').css({'display': 'none'});
            $('#geschaefte-modal-container #geschaefte-modal-content-container').css({'display': 'flex'});
        });
        ajaxReq.error( function ( jqXhr, textStatus, errorMessage ) {
            console.log('error:' + errorMessage);
        });
    });

    function closeGeschaefteModal() {
        $('#geschaefte-modal-logo').attr('src', '');
        $('#geschaefte-modal-companyname').html('');
        $('#geschaefte-modal-partner-id').html('');
        $('#geschaefte-modal-categories').empty();
        $('#geschaefte-modal-boni').empty();
        $('#geschaefte-modal-infotext').html('');
        $('#geschaefte-modal-address').html('');
        $('#geschaefte-modal-map-link').attr('href', '#').hide();
        $('#geschaefte-modal-phone').html('');
        $('#geschaefte-modal-email').html('');
        $('#geschaefte-modal-website').attr('href', '#');
        $('#geschaefte-modal-instagram').attr('href', '#').hide();
        $('#geschaefte-modal-facebook').attr('href', '#').hide();
        $('#geschaefte-modal-can-add-voucher').hide();
        $('#geschaefte-modal-can-redeem-voucher').hide();
        $('#geschaefte-modal-calendar-booking').attr('href', '#').hide();
        $('#geschaefte-modal-featured-images').empty();
        $('#geschaefte-modal-open-hours-additional-info').html('');
        $('#geschaefte-modal-open-hours-arrangement').hide();
        $('.geschaefte-modal-open-hours-times').html('');
        $('#geschaefte-modal-wrapper').css({'display': 'none'});
    }

    $( "#close-geschaefte-modal-button" ).on( "click", function() {
        closeGeschaefteModal();
    });

    $( "#geschaefte-modal-wrapper" ).on( "click", function() {
        closeGeschaefteModal();
    });

    $( "#geschaefte-modal-container" ).on( "click", function(event) {
         event.stopPropagation();
    });


    $( ".participating-partners-filter-item" ).on( "click", function() {
        $( ".participating-partners-filter-item" ).removeClass('filter-active');
        $(this).addClass('filter-active');
        let categoryToFilter = $(this).data('category');
        if(categoryToFilter == 'all') {
            $( ".participating-partners-item" ).each(function( index ) {
                $(this).css('display', 'flex');
            });
        } else {
            $( ".participating-partners-item" ).each(function( index ) {
              if($(this).data('category').includes(categoryToFilter)) {
                $(this).css('display', 'flex');
              } else {
                $(this).css('display', 'none');
              }
            });
        }
    });
});